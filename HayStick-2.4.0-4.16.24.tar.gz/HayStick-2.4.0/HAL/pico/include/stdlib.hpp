#ifndef _HAL_STDLIB_HPP
#define _HAL_STDLIB_HPP

#include <Arduino.h>
#include <pico/stdlib.h>

#endif