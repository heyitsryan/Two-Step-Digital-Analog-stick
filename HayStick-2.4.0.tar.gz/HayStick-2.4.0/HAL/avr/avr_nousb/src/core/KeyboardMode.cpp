#include "core/KeyboardMode.hpp"

#include "core/InputMode.hpp"

KeyboardMode::KeyboardMode() {}

KeyboardMode::~KeyboardMode() {}

void KeyboardMode::SendReport(InputState &inputs) {}

void KeyboardMode::Press(uint8_t keycode, bool press) {}