/* Melee20Button profile by Taker */
#include "modes/Melee20Button.hpp"

#define ANALOG_STICK_MIN 28
#define ANALOG_STICK_NEUTRAL 128
#define ANALOG_STICK_MAX 228

Melee20Button::Melee20Button(socd::SocdType socd_type, Melee20ButtonOptions options) {
    _socd_pair_count = 4;
    _socd_pairs = new socd::SocdPair[_socd_pair_count]{
        socd::SocdPair{&InputState::left,    &InputState::right,   socd_type},
        socd::SocdPair{ &InputState::down,   &InputState::up,      socd_type},
        socd::SocdPair{ &InputState::c_left, &InputState::c_right, socd_type},
        socd::SocdPair{ &InputState::c_down, &InputState::c_up,    socd_type},
    };
    
    _options = options;
    _horizontal_socd = false;
}

void Melee20Button::HandleSocd(InputState &inputs) {
    _horizontal_socd = inputs.left && inputs.right;
    InputMode::HandleSocd(inputs);
}

void Melee20Button::UpdateDigitalOutputs(InputState &inputs, OutputState &outputs) {
    outputs.a = inputs.a;
    outputs.b = inputs.b;
    outputs.x = inputs.x;
    outputs.y = inputs.y;
    outputs.buttonL = inputs.lightshield;
    outputs.buttonR = inputs.z || inputs.midshield;
    outputs.triggerLDigital = inputs.l;
    outputs.triggerRDigital = inputs.r;
    outputs.start = inputs.start;
    outputs.select = inputs.select;
    outputs.home = inputs.home;

    // Turn on D-Pad layer by holding Mod X + Mod Y or Nunchuk C button.
   // if ((inputs.mod_x && inputs.mod_y) || inputs.nunchuk_c) {
      //  outputs.dpadUp = inputs.c_up;
        //outputs.dpadDown = inputs.c_down;
        //outputs.dpadLeft = inputs.c_left;
        //outputs.dpadRight = inputs.c_right;
    
}

void Melee20Button::UpdateAnalogOutputs(InputState &inputs, OutputState &outputs) {
    // Coordinate calculations to make modifier handling simpler.
    UpdateDirections(
        inputs.left,
        inputs.right,
        inputs.down,
        inputs.up,
        inputs.left2,
        inputs.right2,
        inputs.down2,
        inputs.up2,
        inputs.c_left,
        inputs.c_right,
        inputs.c_down,
        inputs.c_up,
        ANALOG_STICK_MIN,
        ANALOG_STICK_NEUTRAL,
        ANALOG_STICK_MAX,
        outputs
    );

    bool shield_button_pressed = inputs.l || inputs.r;

    //CHANGE THESE TO WHAT YOU WANT.
    ;int xCoords[5][5] = {
        {-100,  -50,    0,   50,  100},
        {-100,  -50,    0,   50,  100},
        {-100,  -50,    0,   50,  100},
        {-100,  -50,    0,   50,  100},
        {-100,  -50,    0,   50,  100,}
    }
    ;int yCoords[5][5] = {
        { 100,  100,  100,  100,  100},
        {  50,   50,   50,   50,   50},
        {   0,    0,    0,    0,    0},
        { -50,  -50,  -50,  -50,  -50},
        {-100, -100, -100, -100, -100}
    }

    ;uint8_t xStick;
    if(inputs.left2) {
        xStick = 0;
    } else if(inputs.left) {
        xStick = 1;
    } else if(inputs.right2) {
        xStick = 4;
    } else if(inputs.right) {
        xStick = 3;
    } else {
        xStick = 2;
    }

    uint8_t yStick;
    if(inputs.up2) {
        yStick = 0;
    } else if(inputs.up) {
        yStick = 1;
    } else if(inputs.down2) {
        yStick = 4;
    } else if(inputs.down) {
        yStick = 3;
    } else {
        yStick = 2;
    }

    outputs.leftStickX = ANALOG_STICK_NEUTRAL + xCoords[yStick][xStick];
    outputs.leftStickY = ANALOG_STICK_NEUTRAL + yCoords[yStick][xStick];

    // C-stick ASDI Slideoff angle overrides any other C-stick modifiers (such as
    // angled fsmash).
    if (directions.cx != 0 && directions.cy != 0) {
        // 5250 8500 = 42 58
        outputs.rightStickX = 128 + (directions.cx * 42);
        outputs.rightStickY = 128 + (directions.cy * 58);
    }

    if (inputs.l) {
        outputs.triggerLAnalog = 140;
    }

    if (inputs.r) {
        outputs.triggerRAnalog = 140;
    }

    // Shut off C-stick when using D-Pad layer.
    if ((inputs.mod_x && inputs.mod_y) || inputs.nunchuk_c) {
        outputs.rightStickX = 128;
        outputs.rightStickY = 128;
    }
}
